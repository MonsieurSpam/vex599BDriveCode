/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    19, 7, 18, 8, 9 
// armMotor             motor         20              
// Controller1          controller                    
// anglerMotor          motor         17              
// leftIntake           motor         16              
// rightIntake          motor         10              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;
int iLiftState=0;

// ################################ DEFINE TASKS ###############################
int myTask();

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
 //task StartMyTasks(myTask);
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
void autonomousRollers(std::string direction){
  //activates intake during auto
  if(direction=="in"){  
    rightIntake.spin(reverse,100,pct);
    leftIntake.spin(forward,100,pct);
  }else if(direction=="out"){
    rightIntake.spin(forward,100,pct);
    leftIntake.spin(reverse,100,pct);
  }else if(direction=="break"){
    rightIntake.stop(brake);
    leftIntake.stop(brake);
  }

}
void autonomousAngler(){

}
void autonomous(void) {  
  armMotor.rotateTo(.5,rev,true);
  armMotor.rotateTo(0,rev,true);  
  autonomousRollers("in");
  Drivetrain.driveFor(forward,10,inches,true);
  autonomousRollers("break");
  Drivetrain.turnFor(right,90,degrees,100,vex::velocityUnits::pct,true);

  
} 



/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/



void usercontrol(void) {
  // User control code here, inside the loop
    // ################################ Drive control ###############################
    //redefining motors individually
    motor leftMotorA = motor(PORT19, ratio18_1, false);
    motor leftMotorB = motor(PORT7, ratio18_1, false);
    motor rightMotorA = motor(PORT18, ratio18_1, true); 
    motor rightMotorB = motor(PORT8, ratio18_1, true);  

    while(1){ 
      if(abs(Controller1.Axis3.value())>>5||Controller1.Axis1.value()>>5){
        leftMotorA.spin(forward,(Controller1.Axis3.value()+Controller1.Axis1.value()),pct);
        leftMotorB.spin(forward,(Controller1.Axis3.value()+Controller1.Axis1.value()),pct);
        rightMotorA.spin(forward,(Controller1.Axis3.value()-Controller1.Axis1.value()),pct);
        rightMotorB.spin(forward,(Controller1.Axis3.value()-Controller1.Axis1.value()),pct);
      }
      else {
        leftMotorA.stop(brake);
        leftMotorB.stop(brake);
        rightMotorA.stop(brake);
        rightMotorB.stop(brake);
      }
      
      //raises and lowers arms
      if(Controller1.ButtonL1.pressing()){ 
            iLiftState=0;
            armMotor.spin(forward,100,pct); 
          }else if(Controller1.ButtonL2.pressing()){ 
            iLiftState=0;
            armMotor.spin(reverse,100,pct);
          }else if(Controller1.ButtonUp.pressing()==true){
            iLiftState =1;
          }
          else if(Controller1.ButtonLeft.pressing()==true){
            iLiftState =2;
          } else if(Controller1.ButtonDown.pressing()==true){
      
            iLiftState=3;
          }
          else if (iLiftState == 0) {
            armMotor.stop(hold);
          } 

      //raises and lowers angler
      if(Controller1.ButtonA.pressing()){
        anglerMotor.spin(forward,100,pct);
      }else if(Controller1.ButtonB.pressing()){
        anglerMotor.spin(reverse,100,pct);
      }else{
        anglerMotor.stop(hold);
      } 

      //Intake and outtake
      if(Controller1.ButtonR1.pressing()){
        rightIntake.spin(reverse,100,pct);
        leftIntake.spin(forward,100,pct);
        
      }else if(Controller1.ButtonR2.pressing()){
        rightIntake.spin(forward,100,pct);
        leftIntake.spin(reverse,100,pct); 
      }else{
        rightIntake.stop(coast);
        leftIntake.stop(coast);
      }
          
    wait(20, msec); // Sleep the task for a short amount of time to prevent wasted resources.
    }
} 
    
    
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}

int myTask(){
  while (true) {
    if (iLiftState == 1 ){
      armMotor.rotateTo (420, deg, false);
    }
    else if(iLiftState ==2){
      armMotor.rotateTo (500, deg, false);
    }
    else if(iLiftState==3){
      armMotor.rotateTo (10, deg, false);
    }
  }
} 
